import { useCart as useCartContext } from "@/contexts/cart-context";

export const useCart = useCartContext;
